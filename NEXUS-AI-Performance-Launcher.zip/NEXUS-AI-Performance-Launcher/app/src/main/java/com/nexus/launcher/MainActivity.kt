package com.nexus.launcher

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.DrawablePainter
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class LauncherApp(val label: String, val packageName: String, val activityName: String, val icon: android.graphics.drawable.Drawable)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var apps by remember { mutableStateOf<List<LauncherApp>>(emptyList()) }
                    var search by remember { mutableStateOf("") }
                    var ramPercent by remember { mutableStateOf<Int?>(null) }
                    var batteryTemp by remember { mutableStateOf<Float?>(null) }
                    var refreshHz by remember { mutableStateOf<Float?>(null) }
                    var clock by remember { mutableStateOf("") }

                    LaunchedEffect(Unit) {
                        apps = withContext(Dispatchers.IO) { loadApps() }
                        while (true) {
                            val metrics = withContext(Dispatchers.IO) { readMetrics() }
                            ramPercent = metrics.first
                            batteryTemp = metrics.second
                            refreshHz = metrics.third
                            clock = SimpleDateFormat("EEE, d MMM • HH:mm", Locale.getDefault()).format(Date())
                            delay(5000)
                        }
                    }

                    val filtered = apps.filter { it.label.contains(search, ignoreCase = true) }
                    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("NEXUS", style = MaterialTheme.typography.headlineLarge)
                        Text("Smart home • Gaming-ready • Lightweight")
                        Text(clock, style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricCard("System RAM", ramPercent?.let { "$it%" } ?: "N/A", Modifier.weight(1f))
                            MetricCard("Battery temp", batteryTemp?.let { String.format(Locale.getDefault(), "%.1f°C", it) } ?: "N/A", Modifier.weight(1f))
                        }
                        MetricCard("Display refresh", refreshHz?.let { "${it.toInt()} Hz" } ?: "N/A", Modifier.fillMaxWidth())
                        if (batteryTemp != null && batteryTemp!! >= 42f) {
                            Text("Battery temperature is elevated. Consider pausing intensive use and letting the phone cool.", color = MaterialTheme.colorScheme.error)
                        }
                        OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), label = { Text("Search apps") }, singleLine = true)
                        Text("Applications (${filtered.size})", style = MaterialTheme.typography.titleMedium)
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 84.dp),
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filtered, key = { it.packageName + "/" + it.activityName }) { app ->
                                Card(Modifier.clickable {
                                    val launch = Intent(Intent.ACTION_MAIN).apply {
                                        addCategory(Intent.CATEGORY_LAUNCHER)
                                        component = ComponentName(app.packageName, app.activityName)
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    runCatching { startActivity(launch) }
                                }) {
                                    Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Image(DrawablePainter(app.icon), contentDescription = app.label, modifier = Modifier.size(36.dp))
                                        Text(app.label, fontSize = 12.sp, maxLines = 2)
                                    }
                                }
                            }
                        }
                        Button(onClick = { runCatching { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } }, Modifier.fillMaxWidth()) {
                            Text("Default home settings")
                        }
                    }
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun loadApps(): List<LauncherApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .asSequence()
            .filter { it.activityInfo.packageName != packageName }
            .mapNotNull { item -> runCatching {
                LauncherApp(item.loadLabel(packageManager).toString(), item.activityInfo.packageName, item.activityInfo.name, item.loadIcon(packageManager))
            }.getOrNull() }
            .distinctBy { it.packageName + "/" + it.activityName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
            .toList()
    }

    private fun readMetrics(): Triple<Int?, Float?, Float?> {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val ram = if (info.totalMem > 0L) (((info.totalMem - info.availMem) * 100L) / info.totalMem).toInt().coerceIn(0, 100) else null
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawTemp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val temp = if (rawTemp >= 0) rawTemp / 10f else null
        val dm = getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        return Triple(ram, temp, dm.getDisplay(android.view.Display.DEFAULT_DISPLAY)?.refreshRate)
    }
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium)
        }
    }
}
