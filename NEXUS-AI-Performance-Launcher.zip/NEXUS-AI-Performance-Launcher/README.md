# NEXUS AI Performance Launcher

An early Android HOME launcher prototype using Kotlin and Jetpack Compose.

## Features in this starter
- HOME activity entry point
- Discover and launch visible launcher activities
- App search
- System RAM usage estimate, battery temperature, and display refresh rate when available
- Lightweight periodic metrics refresh
- GitHub Actions debug APK build and artifact upload

## Build
Push to `main`, then open the repository's Actions tab. Download the `nexus-debug-apk` artifact after a successful build and extract `app-debug.apk`.

## Limitations
- This is an early prototype, not a production-ready launcher.
- System RAM usage is not NEXUS process memory usage.
- Battery temperature is not CPU/GPU temperature.
- Ordinary Android apps cannot freely set CPU/GPU clocks or bypass thermal controls.
- Workflow and code must be verified by an actual GitHub Actions run; no build or physical-device test is claimed here.

## Toolchain
JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.2, Kotlin 2.0.21, Android SDK 35.
